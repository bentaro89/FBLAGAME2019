﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RankBar : MonoBehaviour {

	private VariableScript happy;

	// Use this for initialization
	void Start () {

		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script/
		
	}
	
	// Update is called once per frame
	void Update () {

		if (happy.currentrank <= 0) { // The current volunteering rank can never be less than 0.

			happy.currentrank = 0; 
		} else if (happy.currentrank >= 100) { // Allows the player to restart the fundraising rank for a presitge.

			happy.currentrank = happy.currentrank - 100;
			happy.prestigeVol++; 
		}

		transform.localScale = new Vector3 (1f, (happy.currentrank/ happy.maxrank), 1f); // Bar changes size due to rank.
	}
}
