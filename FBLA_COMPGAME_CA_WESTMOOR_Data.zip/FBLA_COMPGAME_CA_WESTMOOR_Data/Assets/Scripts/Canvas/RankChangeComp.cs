﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class RankChangeComp : MonoBehaviour {

	public GameObject[] rankcomp;

	private VariableScript happy;

	public RankBarComp rc;

	public Text prestigeAm;

	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script

		happy.timeremaining -= Time.deltaTime; // Time starts to go down.

		rc = FindObjectOfType<RankBarComp> (); // To access the RankBarComp object.
	}

	// Update is called once per frame
	void Update () {
		prestigeAm.text = (happy.prestigeComp + ""); // Shows the number of times you go past 100 rank in competition.
		Rank (); // Runs Rank.
	}
	void Rank(){ // Shows the rank and medal for competitions.
		if (happy.currentrankcomp >= 0 && happy.currentrankcomp <= 33) {
			rankcomp [0].SetActive (true);
			rankcomp [2].SetActive(false);
			rankcomp [1].SetActive (false);

		} else if (happy.currentrankcomp >= 34 && happy.currentrankcomp <= 66){
			rankcomp [1].SetActive (true);
			rankcomp [0].SetActive (false);
			rankcomp [2].SetActive (false);

		} else if (happy.currentrankcomp >= 67) {
			rankcomp [2].SetActive (true);
			rankcomp [1].SetActive (false);
			rankcomp [0].SetActive (false);
		}
	}
}
