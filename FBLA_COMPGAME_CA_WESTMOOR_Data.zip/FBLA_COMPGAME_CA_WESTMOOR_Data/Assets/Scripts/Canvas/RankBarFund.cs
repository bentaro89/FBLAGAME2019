﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RankBarFund : MonoBehaviour {

	public float maxrank = 100;

	private VariableScript happy;
	// Use this for initialization
	void Start () {

		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.

	}

	// Update is called once per frame
	void Update () {


		if (happy.currentrankfund <= 0) { // The current rank fund can never be less than 0.

			happy.currentrankfund = 0; 
		} else if (happy.currentrankfund >= 100) { // Allows the player to restart the fundraising rank for a presitge.

			happy.currentrankfund = happy.currentrankfund - 100;
			happy.presitgeFund++;
		}
		transform.localScale = new Vector3 (1f, (happy.currentrankfund/ maxrank), 1f); // Bar changes size due to rank.
	}
}
