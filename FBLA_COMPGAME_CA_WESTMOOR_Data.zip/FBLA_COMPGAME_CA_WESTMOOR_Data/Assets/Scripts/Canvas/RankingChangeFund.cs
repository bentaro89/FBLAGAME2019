﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class RankingChangeFund : MonoBehaviour {

	public GameObject[] rankfund;

	private VariableScript happy;

	public RankBarFund fd;

	public Text prestigeAm; 

	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.

		happy.timeremaining -= Time.deltaTime; // Time starts going down.

		fd = FindObjectOfType<RankBarFund> (); // To access the RankBarFund object.
	}

	// Update is called once per frame
	void Update () {
		prestigeAm.text = (happy.presitgeFund + ""); // Shows the number of times you go past 100 rank in fundraising.
		Rank (); // Run Rank.
	}
	void Rank(){ // Shows rank and medal in fundraising.
		if (happy.currentrankfund >= 0 && happy.currentrankfund <= 33) {
			rankfund [0].SetActive (true);
			rankfund [2].SetActive(false);
			rankfund [1].SetActive (false);

		} else if (happy.currentrankfund >= 34 && happy.currentrankfund <= 66){
			rankfund [1].SetActive (true);
			rankfund [0].SetActive (false);
			rankfund [2].SetActive (false);

		} else if (happy.currentrankfund >= 67) {
			rankfund [2].SetActive(true);
			rankfund [1].SetActive (false);
			rankfund [0].SetActive (false);
		}
	}
}
