﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemActiveCheck : MonoBehaviour {
	private VariableScript happy;
	public GameObject[] items, GGitems;
	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(happy.item1Active){ // Shows items in the inventory tab. 
			items [0].SetActive(true);
		}
		if(happy.item2Active){
			items [1].SetActive(true);
		}
		if(happy.item3Active){
			items [2].SetActive(true);
		}

	}
}
