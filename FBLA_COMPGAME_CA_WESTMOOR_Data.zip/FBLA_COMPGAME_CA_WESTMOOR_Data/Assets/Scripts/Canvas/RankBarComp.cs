﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RankBarComp : MonoBehaviour {

	public float maxrank = 100;

	public VariableScript happy; 

	// Use this for initialization
	void Start () {
		
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script

	}

	// Update is called once per frame
	void Update () {

		if (happy.currentrankcomp <= 0) { // The current competition rank can never be less than 0

			happy.currentrankcomp = 0; 
		} else if (happy.currentrankcomp >= 100) { // Allows the player to restart the competition rank for a presitge.

			happy.currentrankcomp = happy.currentrankcomp -100;
			happy.prestigeComp++;

		}

		transform.localScale = new Vector3 (1f, (happy.currentrankcomp/ maxrank), 1f); // Bar changes size due to rank.
	}
}
