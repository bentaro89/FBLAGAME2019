﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RankingChange : MonoBehaviour {

	public GameObject[] rank;

	public RankBar rb;

	private VariableScript happy;

	public Text prestigeAm; 

	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.

		happy.timeremaining -= Time.deltaTime; // Time begins to go down.

		rb = FindObjectOfType<RankBar> (); // To access the RankBar object.
	}
	
	// Update is called once per frame
	void Update () {
		prestigeAm.text = (happy.prestigeVol + ""); // Shows the number of times you go past 100 rank in volunteering.
		Rank (); // Runs Rank.
	}
	void Rank(){ // Shows rank and medal in volunteering.
		if (happy.currentrank >= 0 && happy.currentrank <= 33) {
			rank [0].SetActive (true);
			rank [2].SetActive(false);
			rank [1].SetActive (false);

		} else if (happy.currentrank >= 34 && happy.currentrank <= 66){
			rank [1].SetActive (true);
			rank [0].SetActive (false);
			rank [2].SetActive (false);

		} else if (happy.currentrank >= 67) {
			rank [2].SetActive(true);
			rank [1].SetActive (false);
			rank [0].SetActive (false);
		}
	}
}
