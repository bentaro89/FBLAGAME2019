﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rankcheck : MonoBehaviour {

	public bool check;
	private VariableScript happy;
	public GameObject rankDisplay, inventory, dayss;

	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript>(); // To access the VariableScript script. 
		}
	
	// Update is called once per frame
	void Update () {
		if (!happy.dialogActivate) { // Shows the tab that displays ranks, days, and items.
			if (Input.GetKeyDown (KeyCode.Q)) {
				rankDisplay.SetActive (true); 
				inventory.SetActive (true);
				dayss.SetActive (true);
				check = false;
			}

			if (Input.GetKeyUp (KeyCode.Q) && check == false) { // hides the tab.
				rankDisplay.SetActive (false);
				inventory.SetActive (false);
				dayss.SetActive (false); 
				check = true; 
			}
		}
	}
}
