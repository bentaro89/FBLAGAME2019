﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CompetitionDialogueBox : MonoBehaviour {
	public string[] textLines, questions;
	public GameObject textBox, scoreBox;
	public Text theText, scoreText;
	public int currentLine, endAtLine;
	private PlayerController thePlayer;
	private CompetitionAnswerBox answers;
	private VariableScript happy;
	public string ExitPoint;
	// Use this for initialization
	void Start () {
		answers = FindObjectOfType<CompetitionAnswerBox>(); // To access the CompetitionAnswerBox script.
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
		thePlayer = FindObjectOfType<PlayerController> (); // To access the PlayerController script.
		currentLine = 0; // the first line of text is shown.
		endAtLine = textLines.Length - 1; // the last line is called endAtLine
		GameObject.Find("MusicPlayer").GetComponent<AudioSource>().mute = true; // Mutes the MusicPlayer
	}
	
	// Update is called once per frame
	void Update () {
		theText.text = textLines [currentLine]; // The text shows the current line of dialogue.
		scoreText.text = ("You scored " + answers.answersCorrect + " out of 10."); // Your score is displayed by scoreText.
		if (currentLine == 13) { // If the current line is on 13, the score is shown and the dialogue is disabled.
			scoreBox.SetActive (true);
			textBox.SetActive (false);
		}
		if (currentLine == 14) { // If the current line is on 14, the score is diabled and the dialogue is shown.
			scoreBox.SetActive (false);
			textBox.SetActive (true);
		}
		if (currentLine == endAtLine) { // At the last line
			textBox.SetActive (false); // the text box is disabled
			happy.currentrankcomp += 2 * answers.answersCorrect; // the player gains points on the number of correct answers they got.
			happy.days++; // Gives the player one day for completing any competition.
			Application.LoadLevel ("Hotel"); //the player is moved to the hotel,
			thePlayer.startPoint = ExitPoint; 
			GameObject.Find("MusicPlayer").GetComponent<AudioSource>().mute = false; // the music player is unmuted.
		}
		else if (GameObject.Find("AnswerBoxManager").GetComponent<CompetitionAnswerBox>().answerMade && currentLine <= endAtLine) {
			if (Input.GetKeyDown (KeyCode.Space)) { // If the competition is not finished and no questions are being asked, the player can press Space to continue.
				currentLine++;
			}
		}
	}
}
