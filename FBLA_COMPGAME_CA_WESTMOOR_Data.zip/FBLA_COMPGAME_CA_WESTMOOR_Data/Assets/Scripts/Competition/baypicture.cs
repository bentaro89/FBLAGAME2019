﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class baypicture : MonoBehaviour {
	VariableScript happy;
	SpriteRenderer spriteRenderer;
	public Sprite[] sprite;
	public GameObject adams;
	// Use this for initialization
	void Start () {
		spriteRenderer = gameObject.GetComponent<SpriteRenderer>(); // To access this game object's sprite renderer.
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script
	}
	
	// Update is called once per frame
	void Update () {
		if (happy.bay) { // If the player is in Bay, the banner will read "Bay".
			spriteRenderer.sprite = sprite [0];
		}
		if (happy.state) { // If the player is in State, the banner will read "State".
			spriteRenderer.sprite = sprite [1];
		}
		if (happy.national) { // If the player is in Nationals, the banner will read "Nationals".
			spriteRenderer.sprite = sprite [2];
			adams.SetActive (true);
		}
		else {
			adams.SetActive (false);
		}
	}
}
