﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompetitionScript : MonoBehaviour {
	private VariableScript happy;
	private LevelManager comp;
	void Start(){
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
		comp = FindObjectOfType<LevelManager> ();// To access the LevelManager script.
	}
	void OnTriggerEnter2D (Collider2D other){
		if (other.CompareTag ("Player")) {
			GameObject.Find("MusicPlayer").GetComponent<AudioSource>().mute = true;
			if (happy.bay){ // The 4 competition and Bay Section correspond to the name of the arrays.
				if (gameObject.name == "Openhoteldoor1") {
					comp.LoadLevel (happy.bayCompetitions[0]);
				}
				if (gameObject.name == "Openhoteldoor2") {
					comp.LoadLevel (happy.bayCompetitions[1]);
				}
				if (gameObject.name == "Openhoteldoor3") {
					comp.LoadLevel (happy.bayCompetitions[2]);
				}
				if (gameObject.name == "Openhoteldoor4") {
					comp.LoadLevel (happy.bayCompetitions[3]);
				}
			}
			if (happy.state){ // The 4 competition and State Section correspond to the name of the arrays.
				if (gameObject.name == "Openhoteldoor1") {
					comp.LoadLevel (happy.stateCompetitions[0]);
				}
				if (gameObject.name == "Openhoteldoor2") {
					comp.LoadLevel (happy.stateCompetitions[1]);
				}
				if (gameObject.name == "Openhoteldoor3") {
					comp.LoadLevel (happy.stateCompetitions[2]);
				}
				if (gameObject.name == "Openhoteldoor4") {
					comp.LoadLevel (happy.stateCompetitions[3]);
				}
			}
			if (happy.national){ // The 4 competition and Nationals correspond to the name of the arrays.
				if (gameObject.name == "Openhoteldoor1") {
					comp.LoadLevel (happy.nationalCompetitions[0]);
				}
				if (gameObject.name == "Openhoteldoor2") {
					comp.LoadLevel (happy.nationalCompetitions[1]);
				}
				if (gameObject.name == "Openhoteldoor3") {
					comp.LoadLevel (happy.nationalCompetitions[2]);
				}
				if (gameObject.name == "Openhoteldoor4") {
					comp.LoadLevel (happy.nationalCompetitions[3]);
				}
			}
		}
	
	}
}
