﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
/* 
To Add Questions to Competition
	a) Go to "AnswerBoxManager" -> "CompetitionAnswerBox(Script)"
		1. go to "Answers", Add 4 to "Size", input the 4 answers into the last 4 elements.
		2. go to "When Do Questions End", Add 1. Repeat for "Player Answer"
		3. go to "Correct Answer", Add 1 to "Size", Put the corresponding number into the last element.
			A = 1
			B = 2
			C = 3
			D = 4
	b) Go to "TextBoxManager" -> "CompetitionDialogueBox(Script)"
		1. go to "Text Lines", Add 1 to "Size".
		2. go to "Text Lines", Copy the third to last element and paste it into the second to last element.
		3. go to "Text Lines", Input your questions into the third to last element.
*/ 
public class CompetitionAnswerBox : MonoBehaviour {
	public string[] answers;
	public int answersCorrect, whenDoQuestionsStart, whenDoQuestionsEnd;
	public int[] playerAnswer, correctAnswer;
	int questions;
	public Text bottomRightText, bottomLeftText, topRightText, topLeftText, pressSpace;
	public bool answerMade, oneTime;
	public GameObject answerBoxTopRight, answerBoxTopLeft, answerBoxBottomRight, answerBoxBottomLeft;
	// Use this for initialization
	void Start () {
		answerMade = true; // The player cannot input an answer yet.
		answersCorrect = 0; // The player has not answered any questions correct.
		questions = 0; // The player is on question 1.
	}
	
	// Update is called once per frame
	void Update () { // Plays the competition until it is complete.
		if (GameObject.Find ("TextBoxManager").GetComponent<CompetitionDialogueBox> ().currentLine <= 2 || 
			GameObject.Find ("TextBoxManager").GetComponent<CompetitionDialogueBox> ().currentLine > whenDoQuestionsEnd) 
		{   // Disables boxes until the questions are asked.
			answerBoxTopRight.SetActive (false);
			answerBoxTopLeft.SetActive (false);
			answerBoxBottomRight.SetActive (false);
			answerBoxBottomLeft.SetActive (false);
			pressSpace.text = ("Press Space to Continue"); // "Press Space to Continue" text is shown.
		}

		else if(whenDoQuestionsEnd >= whenDoQuestionsStart && 
			GameObject.Find ("TextBoxManager").GetComponent<CompetitionDialogueBox> ().currentLine >= whenDoQuestionsStart)
		{	// Competition begins showing questions.
			Question (questions); // Runs questions.
		} 
	}
	void Question(int x){ // activates answers boxes so that the player can choose what question
		pressSpace.text = (""); // "Press Space to Continue" is removed.
		answerMade = false; // Player can now choose an answer.
		answerBoxTopRight.SetActive (true);
		answerBoxTopLeft.SetActive (true);
		answerBoxBottomRight.SetActive (true);
		answerBoxBottomLeft.SetActive (true);
		topLeftText.text = answers [questions * 4]; // Top left text is equal to the texts whose arrays are multiples of 4.
		topRightText.text = answers [questions * 4 + 1]; // Top right text is equal to the tests whose arrays are 1 plus multiples of 4.
		bottomLeftText.text = answers [questions * 4 + 2]; // Bottle left text is equal to the tests whose arrays are 1 plus multiples of 4.
		bottomRightText.text = answers [questions * 4 + 3]; // Bottom right text is equal to the tests whose arrays are 1 plus multiples of 4.
		if (Input.GetKeyDown (KeyCode.A)) { // If the player presses A, the player's answer is equal to 1 and points run.
			playerAnswer[x] = 1;
			points ();
		} else if (Input.GetKeyDown (KeyCode.B)) { // If the player presses B, the player's answer is equal to 2 and points run.
			playerAnswer[x] = 2;
			points ();
		} else if (Input.GetKeyDown (KeyCode.C)) { // If the player presses C, the player's answer is equal to 3 and points run.
			playerAnswer[x] = 3;
			points ();
		} else if (Input.GetKeyDown (KeyCode.D)) { // If the player presses D, the player's answer is equal to 4 and points run.
			playerAnswer[x] = 4;
			points ();
		}
	}
	void points (){
		answerMade = true; // The player has entered an answer.
		oneTime = false; // The player has earned a point one time.
		if (!oneTime && playerAnswer[questions] == correctAnswer[questions]){ // If the player's answer is equal to the correct answer of the question, they get a point for the correct answer once.
			answersCorrect++;
			oneTime = true;
		}
		questions++; // Moves on to the next question.
		whenDoQuestionsStart++; // the interger, whenDoQuestionsStart increases by 1.
		GameObject.Find ("TextBoxManager").GetComponent<CompetitionDialogueBox> ().currentLine++; // The next dialogue is shown.
	}

}
