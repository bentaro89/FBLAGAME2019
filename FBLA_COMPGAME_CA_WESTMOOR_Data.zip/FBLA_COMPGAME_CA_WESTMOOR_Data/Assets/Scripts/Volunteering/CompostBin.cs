﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompostBin : MonoBehaviour {

	private VariableScript happy;


	// Use this for initialization
	void Start () {

		happy = FindObjectOfType<VariableScript> (); // to access the script called "Variable Script"

	}

	void OnTriggerStay2D (Collider2D other) {

		if (Input.GetKeyDown (KeyCode.E)) {
			if (other.CompareTag ("Player")) {
				/*if (this.CompareTag ("Bin") && happy.banana) {
					happy.composted = true; 
					happy.bananaActive = false;
				}*/
				if (this.CompareTag ("Pot") && happy.plant) { // When they player presses E while touching the plant, they plant the tree and finish the GoGreen project.
					happy.planted = true; 
					happy.plantActive = false;
					happy.GGfinished = false;
				}
			}
		}
	}
}
