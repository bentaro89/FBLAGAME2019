﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompostPlant : MonoBehaviour {

	private VariableScript happy;

	// Use this for initialization
	void Start () {

		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
	}

	void OnTriggerEnter2D (Collider2D col) {

		if (col.tag == ("Player")) { // if they player touches the plant, they pick up the plant from the ground.
			happy.plant = true; 
			happy.plantActive = false; 
			Destroy (gameObject);

		}
	}
}
