﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompostProject : MonoBehaviour {

	private VariableScript happy;

	// Use this for initialization
	void Start () {

		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
	}

	void OnTriggerEnter2D (Collider2D col) {

		if (col.tag == ("Player")) { // if they player touches the banana peel, they pick up the bannana peel from the ground.
			happy.banana = true; 
			happy.bananaActive = false;
			Destroy (gameObject);
		}
	}
}
