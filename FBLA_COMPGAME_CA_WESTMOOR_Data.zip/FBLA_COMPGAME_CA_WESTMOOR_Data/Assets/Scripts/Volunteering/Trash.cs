﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trash : MonoBehaviour {

	public PointCounter PointC;

	public int addPoint;
	private VariableScript happy;
	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
		PointC = FindObjectOfType<PointCounter> (); // To access the PointCounter script.
	}

	void OnTriggerEnter2D (Collider2D col) {
		if (happy.startFoodShelter) {
			if (col.tag == ("Player")) { // if the player has started the volunteering, they will pick up the trash and gain points for it. 

				PointC.Tpoint = addPoint + PointC.Tpoint;
				Destroy (this.gameObject);
			}
		}
	}
}
