﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PosterMaker : MonoBehaviour {
	private VariableScript happy;	
	SpriteRenderer spriterenderer;
	public Sprite sprite;
	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
		spriterenderer = GetComponent<SpriteRenderer> (); // To access the SpriteRenderer script.
	}
	
	// Update is called once per frame
	void Update(){
		if (happy.Poster) {
			spriterenderer.sprite = sprite; // The poster on the wall turns into the March of Dimes poster.
		}
	}
}
