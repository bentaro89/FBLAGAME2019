﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DinnerDash : MonoBehaviour {

	public bool touchcounter;

	// Use this for initialization
	void Start () {

		touchcounter = false; // The player has not touched the counter., picking up the food.
	}

	void OnTriggerEnter2D (Collider2D col) {

		if (col.tag == ("Player")) { // The player has touched the counter, picking up the food.
			touchcounter = true; 
		}
	}
}
