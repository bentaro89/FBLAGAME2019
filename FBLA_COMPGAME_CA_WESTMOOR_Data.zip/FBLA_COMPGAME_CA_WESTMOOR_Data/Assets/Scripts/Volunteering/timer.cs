﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class timer : MonoBehaviour {

	public Text timeText;
	public float time;

	public VariableScript vs;
	private bool onetime;

	public string leveltoload;
	public PlayerController pc;

	public PointCounter pc2;  
	public string exitpoint; 

	public bool talked;

	// Use this for initialization
	void Start () {

		vs = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
		pc = FindObjectOfType<PlayerController> ();  // To access the PlayerController script.
		pc2 = FindObjectOfType<PointCounter> (); // To access the PointCounter script.
		onetime = true;
		talked = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (talked) {
			time -= Time.deltaTime; // Time begins going down when they player has talked to the volunteering coordinator.
		}
		if (time <= 0) { // When the timer hits 0, the player cannot move and the volunteering is done.
			time = 0; 
			pc.move = false; 
			vs.foodShelter = false;

		}

		if (vs.cheat) {
			if (Input.GetKeyUp (KeyCode.T)) { //If cheats are turned on, the palyer can set the time as 0, ending the volunteering.
				time = 0;
			}
		}
		timeText.text = ("Time: " + time); // The time left is being shown.

		if ( time <= 0 && onetime) { // When the volunteering is over...

			vs.currentrank += pc2.Tpoint; // The points earened goes into the volunteering rank.
			vs.days += 3; // The player gains 3 days
			vs.volunteered = true; // The player has volunteered. 
			onetime = false; // The player can volunteer again after they return.
		} 
		if (time <= 0) { // When the player finishes the volunteering.
			timeText.text = ("Press Space to go back"); // The text will show the text "Press Space to go back".
			pc2.pointDisplay.text = ("You earned " + pc2.Tpoint + " points"); // The text wukk shiw how many points the player has earned.
			vs.startFoodShelter = false; // The volunteering is over.
			vs.move = false; // The player cannot move.
		}

		if (Input.GetKeyDown (KeyCode.Space) && !onetime) { // The player can press Space to leave the volunteering area and can move again.
			Application.LoadLevel (leveltoload);
			pc.startPoint = exitpoint;
			vs.move = true;
		}

	}
}
