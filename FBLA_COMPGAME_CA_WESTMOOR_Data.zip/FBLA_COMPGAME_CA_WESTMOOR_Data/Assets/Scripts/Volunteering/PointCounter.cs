﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PointCounter : MonoBehaviour {

	public PlayerController player;

	public Text pointDisplay;

	public timer timer;

	public int Tpoint = 0;

	public DaySet DaySet;

	// Use this for initialization
	void Start () {

		player = FindObjectOfType<PlayerController> (); // To access the PlayerController script.
		DaySet = FindObjectOfType<DaySet> (); // To access the DaySet script.
		timer = FindObjectOfType<timer> (); // To access the Timer script.
		
	}
	
	// Update is called once per frame
	void Update () {

		pointDisplay.text = (""+ Tpoint); // Displays the points

	}
}
