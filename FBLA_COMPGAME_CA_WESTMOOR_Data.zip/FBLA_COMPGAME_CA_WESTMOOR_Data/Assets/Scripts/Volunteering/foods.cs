﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class foods : MonoBehaviour {

	public PointCounter PointC;

	public int addPoint;
	public GameObject[] the;
	private DinnerDash dash;
	private VariableScript happy;

	// Use this for initialization
	void Start () {
		dash = FindObjectOfType<DinnerDash> (); // To access the DinnerDash script.
		happy = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
	}

	void OnTriggerEnter2D (Collider2D col) {
		if (happy.startFoodShelter) {
			if (col.tag == ("Player") && dash.touchcounter == true) { // If the food shelter volunteering has started and the player has touched the counter with the food, they put the food down and gain points in the minigame.

				PointC.Tpoint = addPoint + PointC.Tpoint;
				the [0].SetActive (true);
				dash.touchcounter = false;
				gameObject.SetActive (false);
			}
		}
}
}