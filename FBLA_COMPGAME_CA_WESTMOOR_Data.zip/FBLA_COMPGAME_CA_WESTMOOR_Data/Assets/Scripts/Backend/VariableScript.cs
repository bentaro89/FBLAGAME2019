﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VariableScript : MonoBehaviour {

	//This script is used to save data when going from scene to scene as it will deleted after being created.

	public int happy, money, currentline, days, prestigeVol, prestigeComp, presitgeFund, sprite;
	public bool item1, 				item2, 			item3, 				dialogActivate, 	Poster, 
				oneTimePham, 		item1Active, 	item2Active, 		item3Active, 		move, 
				bay, 				state, 			national, 			banana, 			plant, 
				GoGreenFinished, 	bananaActive, 	plantActive, 		introduction,	 	moveTrigger, 
				talkTrigger, 		composted, 		planted, 			talkGov, 			volunteered, 
				Options, 			skipIntro, 		finishedBay, 		finishedState, 		finishedNational,
				optionPoster, 		introgov,  		GGfinished, 		govfin, 			section, 
				oneTimeDoor, 		foodShelter, 	startFoodShelter, 	govtalk, 			cheat,
				moving,				bayCar,			stateBus,			nationalsPlane;
	public float points, timeremaining, currentrank, currentrankfund, currentrankcomp, maxrank;
	public string[] dialoglines, bayCompetitions, stateCompetitions, nationalCompetitions, introductionLines;
	//This is where all the variables that need to not be destroyed when switching scenes

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {

	}
}
