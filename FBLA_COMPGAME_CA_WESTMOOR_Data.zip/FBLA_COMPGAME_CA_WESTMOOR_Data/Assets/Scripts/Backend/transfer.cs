﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class transfer : MonoBehaviour {

	public Transform pointA;

	public PlayerController player;

	// Use this for initialization
	void Start () {

		pointA = GetComponent<Transform> (); 
		player = FindObjectOfType<PlayerController> ();
	}

	void OnTriggerEnter2D (Collider2D col) {

		if (col.CompareTag("Player")) {
			
			player.rb2d.transform.position = pointA.transform.position;
			print (pointA);
		}//makes sure transform points correlate with each other in order to teleport to different rooms/area
	}
}
