﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueHolder : MonoBehaviour {

	public string dialogue;
	private DialogueManager dMan; 
	private VariableScript happy;
	public string[] dialogueLines,dialogueLinesWithPosters, dialogueLinesNoBottle, dialognothing, dialogbanana, dialogplant, dialoggov1, dialoggov2, 
	dialogfinish, dialogVolF, dialogGov, dialogGovFinish, optionDialog, dialogVolFF, dialogBin; 
	public bool donated, fundcheck, oneTimePham, Section;
	public int donation, donationWithPosters;

	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // to access the script called "Variable Script"
		dMan = FindObjectOfType<DialogueManager> ();// to access the script called "Dialogue Manager"
		donated = false; // donated starts false when the script is intialized.
		if (!happy.introduction && !happy.skipIntro) { // Starts introduction.
			happy.dialoglines = happy.introductionLines;
			happy.currentline = 0;
			dMan.ShowDialogue ();
		}
	}
	void Update(){
		if (this.gameObject.name == "IntroGirl" && this.CompareTag ("IntroTrigger") && happy.skipIntro){ // Changes tag of the IntroGirl now that the introduction is over.
			transform.gameObject.tag = "donater";
		}
	}
	void OnTriggerEnter2D(Collider2D other){
		if (other.CompareTag ("Player")) { // If the player and this object touch.
			if (this.CompareTag ("OptionPoster") && happy.item3 && happy.item2) { // Gives options for the poster if they have the marker and poster paper.
				happy.optionPoster = true;
				happy.Options = true;
				dMan.optionDialogue = optionDialog;
				happy.dialoglines = dialogueLines; 
				happy.currentline = 0; 
				dMan.ShowDialogue (); 
			}
			if (this.CompareTag ("Bay") && happy.finishedBay) { // Opens options to go to Bay when you touch the car.
				happy.dialoglines = dialogueLines; 
				dMan.optionDialogue = optionDialog;
				happy.currentline = 0; 
				dMan.ShowDialogue (); 
				happy.Options = true;
				happy.section = true;
				happy.bayCar = true; 
			}
			if (this.CompareTag ("State") && happy.finishedState) { // Opens options to go to State when you touch the bus.
				happy.dialoglines = dialogueLines; 
				dMan.optionDialogue = optionDialog;
				happy.currentline = 0; 
				dMan.ShowDialogue (); 
				happy.Options = true;
				happy.section = true;
				happy.stateBus = true;
			}
			if (this.CompareTag ("Nationals") && happy.finishedNational) { // Opens options to go to Nationals when you touch the plane.
				happy.dialoglines = dialogueLines; 
				dMan.optionDialogue = optionDialog;
				happy.currentline = 0; 
				dMan.ShowDialogue (); 
				happy.Options = true;
				happy.section = true;
				happy.nationalsPlane = true;
			}
		}
	}
		
	void OnTriggerStay2D (Collider2D other) {
	
		if (other.CompareTag ("Player")) { // If the player and this object touch.
			if (this.CompareTag ("Bin") && happy.banana && !happy.composted) {	// If the player touches the bin with the banana, dialogue will appear.
				happy.dialoglines = dialogBin;
				happy.currentline = 0; 
				dMan.ShowDialogue ();
			}
			if (Input.GetKeyDown (KeyCode.E)) { // If the player presses E on this object.
				if (this.CompareTag("Cheat")){
					happy.dialoglines = dialogueLinesNoBottle; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
					happy.cheat = true;
				}
				if (this.CompareTag("Mr. Adams")){
					happy.dialoglines = dialogueLinesNoBottle; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
				}
				if (this.CompareTag ("Bin") && happy.banana) { // The player will compost the banana. 
					happy.composted = true; 
					happy.bananaActive = false;
				}
				if (this.CompareTag("IntroTrigger")){ // the player has talked to the introduction character.
					happy.talkTrigger = true;
				}
				if(!happy.oneTimePham && this.CompareTag("Pham") && !happy.dialogActivate){ // The player has talked ot Mr. Pham for the first time.
					happy.item1Active = true;
					happy.item2Active = true;
					happy.item3Active = true;
					happy.dialoglines = dialogueLines; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
					happy.oneTimePham = true;
				}
				else if (!happy.dialogActivate && happy.item1 && this.CompareTag ("donater") && donated == false && happy.Poster) { // The player asks a character for a donation with the poster being up.
					happy.money += donationWithPosters;
					donated = true;
					happy.dialoglines = dialogueLinesWithPosters; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
				} else if (!happy.dialogActivate && happy.item1 && this.CompareTag ("donater") && donated == false) { // The player asks a character for a donation without the poster being up.

					happy.money += donation;
					donated = true;
					happy.dialoglines = dialogueLines; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
				} else if (this.CompareTag ("donater")) { // The player talks to the character.
					happy.dialoglines = dialogueLinesNoBottle; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
				} else if (this.CompareTag ("HotelPham") && !oneTimePham) { // The player talks to Mr. Pham in the hotel for the first time.
					happy.dialoglines = dialogueLinesNoBottle; 
					happy.currentline = 0; 
					dMan.ShowDialogue ();
					oneTimePham = true;

				} else if (this.CompareTag ("HotelPham")) { // The player talks to Mr. Pham.
					happy.dialoglines = dialogueLines; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
				} else if (this.CompareTag ("Pham") && happy.money >= 100) { // The player talks to Mr. Pham and gives all the money they have to him for days and fundraising rank.
					happy.dialoglines = dialogueLinesNoBottle; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
					happy.currentrankfund += 50;
					happy.days += 3;
					happy.money = 0;
				} else if (this.CompareTag ("Pham")) { // The player talks to Mr. Pham.
					happy.dialoglines = dialogueLinesWithPosters; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
				}
				if (this.CompareTag ("GoGreenCoordinator")) { //The player talks Touch the GoGreen coordinator.

					if (!happy.banana && !happy.plant && !happy.GGfinished) { // Dialogue talking to the GoGreen coordinator for the first time.
						happy.dialoglines = dialognothing;
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.bananaActive = true; 
					} 
					if ( !happy.plant && !happy.GGfinished && happy.composted) { // Dialogue for after the player composts the banana.
						happy.dialoglines = dialogbanana;
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.plantActive = true; 
					}
					if (happy.banana && happy.plant && !happy.GGfinished && happy.planted) { // Dialogue for after the player plants the tree.
						happy.dialoglines = dialogplant; 
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
					}
					if (happy.GGfinished && !happy.introgov && !happy.govfin) {  // Dialogue for after the player finishes the GoGreen project.
						happy.dialoglines = dialoggov1; 
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.introgov = true;
					}
					if (happy.banana && happy.plant && !happy.GGfinished && happy.planted) {  // Dialogue for when the player is done with the GoGreen project tasks.
						happy.dialoglines = dialogfinish; 
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.days += 3; 
						happy.GGfinished = true; 
					}

					if (happy.GGfinished && happy.introgov && !happy.govfin) {  // Dialogue for the introduction to the volunteering project.
						happy.dialoglines = dialoggov2; 
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.govfin = true;
					}
				}
				if (this.CompareTag ("GovOff")) {
					if (!happy.talkGov && !happy.volunteered && !happy.govfin) { // Dialogue for when the player talks to the government official for the first time.
						happy.dialoglines = dialogVolFF; 
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.talkGov = false;
					}
					if (!happy.talkGov && !happy.volunteered && happy.govfin) { // Dialogue for when the player hasnt talked to the government official or volunteered.
						happy.dialoglines = dialogVolF; 
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.talkGov = false;
					}

					if (happy.talkGov && happy.volunteered&& happy.govfin && happy.govtalk) {  // Dialogue for after the player talks to the government official after finishing the volunteering
						happy.dialoglines = dialogGovFinish;
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
					}
					if (!happy.talkGov && happy.volunteered&& happy.govfin) { // Dialogue for after the player finishes volunteering project.
						happy.dialoglines = dialogGov;
						happy.currentline = 0; 
						dMan.ShowDialogue (); 
						happy.days += 3;
						happy.talkGov = true;
						happy.govtalk = true;
					}
				}
				if (this.CompareTag ("Shelterer")) { // Starts the food shelter if this object is the Shelterer.
					happy.dialoglines = dialogueLines; 
					happy.currentline = 0; 
					dMan.ShowDialogue (); 
					happy.foodShelter = true;
					happy.startFoodShelter = true;
				}
			}
		}
	}
}