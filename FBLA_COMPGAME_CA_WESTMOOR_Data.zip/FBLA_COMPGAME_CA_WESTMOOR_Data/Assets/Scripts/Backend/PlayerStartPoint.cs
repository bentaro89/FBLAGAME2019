﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStartPoint : MonoBehaviour {

	private PlayerController thePlayer;
	private CameraFollow theCamera;

	public string PointName;

	// Use this for initialization
	void Start () {

		string thePlayer = GameObject.Find("Player").GetComponent<PlayerController> ().startPoint;

		if (thePlayer == PointName) //make sures that the the player teleports to the intended room{
			GameObject.Find("Player").GetComponent<PlayerController> ().transform.position = transform.position;

			theCamera = FindObjectOfType<CameraFollow> ();
			theCamera.transform.position = new Vector3 (transform.position.x, transform.position.y, theCamera.transform.position.z);
		}//teleports player to other rooms and areas between scenes. 
	}

