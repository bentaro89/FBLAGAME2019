﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DaySet : MonoBehaviour {

	public GameObject dayBox;
	public Text daytext;

	private VariableScript happy;

	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // to access the script called "Variable Script"
	}
	
	// Update is called once per frame
	void Update () {

		daytext.text = ("Day: " + happy.days); // Shows the number of days.

		if (happy.days >= 10) {
			happy.finishedBay = true; // If there has been more than 10 days, Bay Section is available.
		} 
		if (happy.days >= 20) {
			happy.finishedState = true; // If there has been more than 20 days, State Section is available.
		}
		if (happy.days >= 30) {
			happy.finishedNational = true; // If there has been more than 30 days, Nationals is available.
		}
	}
}
