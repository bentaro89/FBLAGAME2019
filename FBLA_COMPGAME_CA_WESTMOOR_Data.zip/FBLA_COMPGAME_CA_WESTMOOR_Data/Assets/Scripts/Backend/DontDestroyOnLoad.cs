﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DontDestroyOnLoad : MonoBehaviour {
	public static DontDestroyOnLoad Instance;
	// Use this for initialization
	void Start () {
		if (Instance) {
			DestroyImmediate (this); // Destroys any created copies of this object.
		} else {
			DontDestroyOnLoad (this); // Keeps this object from scene to scene.
			Instance = this; // This object has been created.
		}
	}
	
	// Update is called once per frame
	void Update () {

	}
}
