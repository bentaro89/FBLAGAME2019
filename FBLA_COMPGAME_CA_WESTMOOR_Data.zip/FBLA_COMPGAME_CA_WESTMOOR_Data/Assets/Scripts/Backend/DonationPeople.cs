﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DonationPeople : MonoBehaviour {

	public int item1, item2, item3; // to intialize the 3 intergers for the 3 items

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
