﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour {

	public void LoadLevel(string name){
		SceneManager.LoadScene(name); // Loads the scene with the same name as "name".
	}

	public void Quitrequest(){
		Application.Quit (); // Quits the game.
	}
}
