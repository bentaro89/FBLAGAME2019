﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CPUMovement : MonoBehaviour
{
	private Vector3 CPUPos;
	private Vector2 upPos;
	private Vector2 downPos;
	public int rangeY = 2;
	public int Yrange = 2;

	private Rigidbody2D rb2d;

	private bool inLine;
	public RaycastHit2D lineMove;

	public DialogueManager dMan;

	public bool canMove; 
	public bool moveAgain;

	public int i;

	// Use this for initialization
	void Start ()
	{

		rb2d = GetComponent<Rigidbody2D> ();
		dMan = FindObjectOfType<DialogueManager> ();

		upPos.y	= transform.position.y + rangeY;
		downPos.y = transform.position.y - Yrange;
		upPos.x = transform.position.x;
		downPos.x = transform.position.x; 

		canMove = true;

		rb2d.velocity = new Vector3 (0f, 3f);



	}
	
	// Update is called once per frame
	void Update ()
	{

		if (!canMove) {

			rb2d.velocity = Vector2.zero;
			return;
		}

		CPUPos = transform.position;

		Debug.DrawLine (upPos, downPos, Color.red);
		lineMove = Physics2D.Linecast (upPos, downPos);

		if (rb2d.position.y >= upPos.y) {
			rb2d.velocity = new Vector3 (0f, -3f);
			print (rb2d.position.y);
			print (upPos.y);
		}
	
		if (rb2d.position.y <= downPos.y) {
			rb2d.velocity = new Vector3 (0f, 3f);
		}
	}
}