﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

	public GameObject targetPlayer;
	private Vector3 targetpos;
	public float movespeed;

	public BoxCollider2D boundsBox;

	private Vector3 minBounds;
	private Vector3 maxBounds;

	private Camera theCamera;
	private float halfHeight;
	private float halfWidth;

	private static bool cameraExists;

	// Use this for initialization
	void Start () {

		if (!cameraExists) {

			cameraExists = true; 
			DontDestroyOnLoad (transform.gameObject);
		} else {
			Destroy (gameObject);
		}//make sure that the camera exists 
	}
	

	void Update () {

		targetpos = new Vector3 (targetPlayer.transform.position.x, targetPlayer.transform.position.y, transform.position.z);
		transform.position = Vector3.Lerp (transform.position, targetpos, movespeed * Time.deltaTime);
	}//updates the player to the center of the camera view
}
