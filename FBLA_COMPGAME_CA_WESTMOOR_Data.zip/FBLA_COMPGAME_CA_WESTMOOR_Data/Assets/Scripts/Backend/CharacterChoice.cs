﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterChoice : MonoBehaviour {
	SpriteRenderer spriteRenderer;
	private VariableScript happy;
	public Sprite[] sprites;
	// Use this for initialization
	void Start () {
		spriteRenderer = gameObject.GetComponent<SpriteRenderer>(); // To access the objects sprite.
		happy = FindObjectOfType<VariableScript>(); //To access the VariableScript script
	}
	void Update(){ // Allows the player to choose their character.
		if (this.gameObject.name == "sprite" && Input.GetKeyDown (KeyCode.Return)) {
			GameObject.Find ("LevelManager").GetComponent<LevelManager> ().LoadLevel ("Hallway"); // Loads the Hallway Scene.
		}
		if (this.gameObject.name == "sprite" && Input.GetKeyUp (KeyCode.UpArrow)) { // Changes the sprite value by pressing the UpArrow.
			happy.sprite += 1;
			if (happy.sprite == 2) {
				happy.sprite = 0;
			}			
		}
		GetComponent<SpriteRenderer>().sprite = sprites [happy.sprite]; // Shows the character that corresponds to the sprite value.
	}
}
