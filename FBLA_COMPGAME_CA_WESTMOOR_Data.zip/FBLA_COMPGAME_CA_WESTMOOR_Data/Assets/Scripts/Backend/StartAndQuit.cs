﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartAndQuit : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (this.gameObject.name == "Start" && Input.GetKeyDown (KeyCode.Return)) {
			GameObject.Find ("LevelManager").GetComponent<LevelManager> ().LoadLevel ("character selection"); //Loads character selection screen after pressing enter.
		}
		if (this.gameObject.name == "Quit" && Input.GetKeyDown (KeyCode.Q)) {
			GameObject.Find ("LevelManager").GetComponent<LevelManager> ().Quitrequest(); //Quits application after pressing Q.
		}
	}
}
