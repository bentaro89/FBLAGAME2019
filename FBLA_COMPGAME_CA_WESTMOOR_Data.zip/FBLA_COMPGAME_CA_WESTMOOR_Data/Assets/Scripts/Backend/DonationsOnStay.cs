﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DonationOnStay: MonoBehaviour {
	public bool oneTimeADay;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnTriggerStay2D(Collider2D other){
		if (other.CompareTag("Player")){
			if (!oneTimeADay){
				GameObject.Find ("VariableScript").GetComponent<VariableScript> ().money++;
				oneTimeADay = true; 
			}
		} // After speaking to a character, the player can speak to them until they leave the scene and come back.
	}
}
