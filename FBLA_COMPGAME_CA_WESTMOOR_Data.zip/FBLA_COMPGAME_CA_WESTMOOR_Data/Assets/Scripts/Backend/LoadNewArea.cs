﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadNewArea : MonoBehaviour {

	public string levelToLoad;

	public string ExitPoint;
	private VariableScript happy;

	private PlayerController thePlayer;
	// Use this for initialization
	void Start () {
		thePlayer = FindObjectOfType<PlayerController> (); // to access the PlayerController script. 
		happy = FindObjectOfType<VariableScript> (); // to access the variableScript script.
		Scene currentScene = SceneManager.GetActiveScene (); // to find the scene's name.
		string sceneName = currentScene.name;
		if (sceneName == "Trash MG" || sceneName == "FoodShelter" || sceneName == "Outsideworld") {
			GameObject.Find ("MusicPlayer").GetComponent<AudioSource> ().mute = true; //mutes MusicPlayer if the player is in either the Trash MG, FoodShelter, or Outsideworld scene.
		} else {
			GameObject.Find ("MusicPlayer").GetComponent<AudioSource> ().mute = false; // unmutes MusicPlayer.
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerStay2D(Collider2D other) {

		if (other.gameObject.name == "Player") {
			
			Application.LoadLevel (levelToLoad);
			thePlayer.startPoint = ExitPoint;
			happy.bay = false;
			happy.state = false;
			happy.national = false;
			happy.stateBus = false;
			happy.bayCar = false;
			happy.nationalsPlane = false;
		} /* If the object and the player are touching, the scene with the same name given to levelToLoad will load,
		     the player will spawn at the exit point and happy.bay, happy.state, happy.national will be set false.*/
	}
}
