﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public float moveSpeed, speedmove;
	public Sprite[] sprite;
	SpriteRenderer spriteRenderer;
	private Animator anim;
	public Rigidbody2D rb2d;
	public bool move;
	private static bool playerExists;
	public string startPoint, levelToLoad; 
	private VariableScript happy; 


	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // to access the script called "Variable Script"
		rb2d = GameObject.FindGameObjectWithTag ("Player").GetComponent<Rigidbody2D> (); // to access the rigidbody2D component on the player.
		anim = GetComponent<Animator> (); // to access the animator on the player.

		happy.move = true;

		if (!playerExists) {

			playerExists = true; 
			DontDestroyOnLoad (transform.gameObject);
		} else {
			Destroy (gameObject);
		} // If the player is already in the scene in "DontDestroyOnLoad", it will keep the old player and delete the copy created in the scene.

		speedmove = 1f;

	}
	
	// Update is called once per frame
	void Update () {
		GetComponent<SpriteRenderer>().sprite = sprite [happy.sprite];
		print (happy.sprite);
		if (Input.GetKeyUp (KeyCode.Escape)){
			Application.Quit(); // Quits the application by pressing Q.
		}
		if (!happy.move) {
			moveSpeed = 0; // to stop the player when dialogue appears
		} 
		if (happy.move) {
			moveSpeed = 20;
		}
		if (happy.cheat) { // For demonstration purposes or after completing all tasks.
			if (Input.GetKeyUp (KeyCode.Tab)) {
				speedmove = 2.5f;
			} // Increases movement by 2.5 times.

			if (Input.GetKeyUp (KeyCode.LeftShift)) {
				speedmove = 1f;
			} // Reverts movement speed back to normal.

			if (Input.GetKeyUp (KeyCode.M)) {
				happy.money = 100;
			} // Gives $100 to the bottle. 

			if (Input.GetKeyUp (KeyCode.N)) {
				happy.days += 30;
			} // Increases days by 30.
		}
		if ((Input.GetAxisRaw ("Vertical") > 0 || Input.GetAxisRaw ("Vertical") < 0) &&
		    (Input.GetAxisRaw ("Horizontal") > 0 || Input.GetAxisRaw ("Horizontal") < 0)) {
			transform.Translate(new Vector2 (Input.GetAxisRaw ("Horizontal") * moveSpeed * Time.deltaTime *speedmove / Mathf.Sqrt(2), 
											Input.GetAxisRaw ("Vertical") * moveSpeed * Time.deltaTime *speedmove / Mathf.Sqrt(2)));
		} // If the player presses vertical and horizontal movement keys (W,A,S,D or arrow keys), they move diaglonally.

		if (Input.GetAxisRaw ("Vertical") == 0) {
			
			if (Input.GetAxisRaw ("Horizontal") > 0.5 || Input.GetAxisRaw ("Horizontal") < 0.5) {

				transform.Translate(new Vector2 (Input.GetAxisRaw ("Horizontal") * moveSpeed * Time.deltaTime *speedmove, 0f));
			}
		} // Player can move horizontally.

	
		if (Input.GetAxisRaw ("Horizontal") == 0) {

			if (Input.GetAxis ("Vertical") > 0.5 || Input.GetAxis ("Vertical") < 0.5) {

				transform.Translate (new Vector2 (0f, Input.GetAxisRaw ("Vertical") * moveSpeed * Time.deltaTime* speedmove));
			}
		} // Player can move veritcally.

		anim.SetFloat("MoveX", Input.GetAxisRaw ("Horizontal")); // Animates moving horizontally
		anim.SetFloat("MoveY", Input.GetAxis("Vertical")); // Animates moving vertically

		if (happy.sprite == 1) {

			anim.SetFloat ("Gstatic", 1f);
		}
	}
}
