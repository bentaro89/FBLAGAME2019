﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteChanger : MonoBehaviour {
	SpriteRenderer spriteRenderer;
	private VariableScript happy;
	public Sprite[] sprites;
	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> ();
		spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
	}
	void Update(){
		if(happy.bay){
			spriteRenderer.sprite = sprites [0];
		} // if happy.bay is true, Bay Section is now available.
		if(happy.state){
			spriteRenderer.sprite = sprites [1];
		} // if happy.state is true, State Section is now available.
		if(happy.national){
			spriteRenderer.sprite = sprites [2];
		} // if happy.national is true, Nationals is now available.
	}
}
