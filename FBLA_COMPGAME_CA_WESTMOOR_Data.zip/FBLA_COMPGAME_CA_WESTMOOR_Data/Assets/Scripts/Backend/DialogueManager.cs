﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour {

	public GameObject dBox;
	public Text dText;
	public Text[] optionText;
	private CPUMovement CPU;
	private PlayerController PC;
	private VariableScript happy;
	public bool oneTimePoster;
	public GameObject[] doors, options;
	public string[] optionDialogue;
	private PlayerController thePlayer;
	public string ExitPoint;
	private timer time;

	public string levelToLoad;
	public int firstStep, secondStep,thirdStep;

	// Use this for initialization
	void Start () {
		happy = FindObjectOfType<VariableScript> (); // to access the script called "Variable Script"
		CPU = FindObjectOfType<CPUMovement> (); // to access the script called "CPU Movement"
		PC = FindObjectOfType<PlayerController> (); // to access the script called "PlayerController"
		time = FindObjectOfType<timer>(); // to access the script called "timer"
		happy.currentline = 0;
	}
	
	// Update is called once per frame
	void Update () {

		if (!happy.skipIntro) {
			IntroductionAndNextLine (); // Skips introduction dialogue
		}

		if (happy.currentline == happy.dialoglines.Length) { // When dialogue ends, all dialogue boxes are hidden and all other variables go back to normal.

			dBox.SetActive (false);
			happy.dialogActivate = false;
			happy.move = true;
			options [0].SetActive (false);
			options [1].SetActive (false);
			options [2].SetActive (false);
			happy.Options = false;
			happy.introduction = true;
			happy.currentline = 0; 
			happy.section = false;
			if (happy.foodShelter) {
				time.talked = true; // starts timer
			} //
			if (happy.bay || happy.state || happy.national) {
				Application.LoadLevel ("Hotel");
				PC.startPoint = ExitPoint;
			} // if the player chooses to go to any of the sections, they will spawn in the hotel.
		}

		if (happy.currentline <= happy.dialoglines.Length) {
			dText.text = happy.dialoglines [happy.currentline];  // shows current line of text.
		}
		if (happy.currentline == happy.dialoglines.Length - 1 && happy.Options) {
			Choices (); // if the object has options, Choices will run.
		}
		if (happy.dialogActivate && Input.GetKeyDown (KeyCode.Space) && happy.skipIntro && !happy.Options) {

			happy.currentline++; // goes to the next line of text
			happy.move = false; // player cannot move.
		}
			
	}
	public void showBox(string dialogue) { // Shows the dialogue box.

		happy.dialogActivate = true;
		dBox.SetActive(true);
		dText.text = dialogue;

	} 

	public void ShowDialogue() { // Shows dialogue and stops player from moving

		happy.dialogActivate = true;
		dBox.SetActive (true);
		happy.move = false; 

	}
	public void IntroductionAndNextLine(){
		if (!happy.introduction) { // Player can not leave the hallway if the introduction is not finished
			doors [0].GetComponent<LoadNewArea> ().enabled = false;
			doors [1].GetComponent<LoadNewArea> ().enabled = false;
			doors [2].GetComponent<DialogueHolder> ().enabled = false;
			doors [3].GetComponent<LoadNewArea> ().enabled = false;
			doors [0].GetComponent<BoxCollider2D> ().enabled = false;
			doors [1].GetComponent<BoxCollider2D> ().enabled = false;
			doors [2].GetComponent<BoxCollider2D> ().enabled = false;
			doors [3].GetComponent<BoxCollider2D> ().enabled = false;
		}
		if (happy.introduction && !happy.oneTimeDoor) { // Player is free to leave the hallway.
			doors [0].GetComponent<LoadNewArea> ().enabled = true;
			doors [1].GetComponent<LoadNewArea> ().enabled = true;
			doors [2].GetComponent<DialogueHolder> ().enabled = true;
			doors [3].GetComponent<LoadNewArea> ().enabled = true;
			doors [0].GetComponent<BoxCollider2D> ().enabled = true;
			doors [1].GetComponent<BoxCollider2D> ().enabled = true;
			doors [2].GetComponent<BoxCollider2D> ().enabled = true;
			doors [3].GetComponent<BoxCollider2D> ().enabled = true;
			happy.oneTimeDoor = true;
			happy.skipIntro = true;
		}
		if (!happy.introduction && happy.currentline <= happy.dialoglines.Length) {
			dText.text = happy.dialoglines [happy.currentline]; // Shows current line of text
			if (!happy.introduction && happy.currentline == firstStep) { // Player must complete the first task of introduction.
				happy.dialogActivate = false;
				GameObject.Find ("IntroBox").SetActive (true);
				dBox.SetActive (false);
				happy.move = true;
				if (happy.moveTrigger) {
					happy.currentline++;
					happy.move = false;
					happy.dialogActivate = true;
					dBox.SetActive (true);
					GameObject.Find ("IntroBox").SetActive (false);
				}
			} 
			if (!happy.introduction && happy.currentline == secondStep) { // Player must complete the second task of introduction.
				happy.dialogActivate = false;
				dBox.SetActive (false);
				if (Input.GetKeyUp (KeyCode.Q)) {
					happy.currentline++;
					happy.dialogActivate = true;
					dBox.SetActive (true);
				}
			}			
			if (!happy.introduction && happy.currentline == thirdStep) { // Player must complete the third task of introduction.
				happy.dialogActivate = false;
				dBox.SetActive (false);
				happy.move = true;
				if (happy.talkTrigger) {
					happy.currentline++;
					happy.move = false;
					happy.dialogActivate = true;
					dBox.SetActive (true);
				}
			} 

			else if (happy.dialogActivate && Input.GetKeyDown (KeyCode.Space)) { // Goes to the next line after pressing the space bar.

				happy.currentline++; 
				happy.move = false;
			}
		}
	}
	public void Choices(){
		if (happy.optionPoster) { // When the player is at the poster, 2 options will appear.
			options [0].SetActive (true);
			options [2].SetActive (true);
			optionText [0].text = optionDialogue [0];
			optionText [1].text = optionDialogue [1];
			optionText [2].text = optionDialogue [2];
			if (Input.GetKeyDown (KeyCode.Alpha1)) { // if they press 1, they will put up the March of Dimes poster.
				happy.currentline++;
				happy.Poster = true;
				happy.item2 = false;
				happy.item3 = false;
			}
			if (Input.GetKeyDown (KeyCode.Alpha2)) { // if they press 2, they will do nothing.
				happy.currentline++;
			}
		}
		if (happy.section) { // When the player goes to the conference door.
			options[0].SetActive(true);
			options[1].SetActive(true);
			optionText [0].text = optionDialogue [0];
			optionText [1].text = optionDialogue [1];
			if (Input.GetKeyDown (KeyCode.Alpha1) && happy.bayCar) { // If the player presses 1 and are at the car, they will go to Bay Section.
				happy.currentline++;
				happy.bay = true;
				happy.state = false;
				happy.national = false;
				happy.section = false;
			}
			if (Input.GetKeyDown (KeyCode.Alpha1) && happy.stateBus) { // If the player presses 1 and are at the bus, they will go to State Section.
				happy.currentline++;
				happy.bay = false;
				happy.state = true;
				happy.national = false;
			}
			if (Input.GetKeyDown (KeyCode.Alpha1) && happy.nationalsPlane) { // If the player presses 1 and are at the plane, they will go to Nationals.
				happy.currentline++;
				happy.bay = false;
				happy.state = false;
				happy.national = true;
			}
			if (Input.GetKeyDown(KeyCode.Alpha2)) { // If the player presses 2, they do nothing.
				happy.currentline++;
				happy.nationalsPlane = false;
				happy.stateBus = false;
				happy.bayCar = false;
			}
		}
	}
}