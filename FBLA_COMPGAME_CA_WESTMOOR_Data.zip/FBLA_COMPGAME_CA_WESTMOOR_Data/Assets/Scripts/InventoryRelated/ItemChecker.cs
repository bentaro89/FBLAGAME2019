﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemChecker : MonoBehaviour {

	private VariableScript inven; 

	void Start () {

		inven = FindObjectOfType<VariableScript> ();
	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.CompareTag ("Player")) { // If the player touches the object...
			if (gameObject.name == "item1") { // ... item1 , they will have it in their inventory and the item will be deleted from the map.
				inven.item1 = true;
				inven.item1Active = false;
				Destroy (gameObject);
			}
			if (gameObject.name == "item2") { // ... item1 , they will have it in their inventory and the item will be deleted from the map.
				inven.item2 = true;
				inven.item2Active = false;
				Destroy (gameObject);
			}
			if (gameObject.name == "item3") { // ... item1 , they will have it in their inventory and the item will be deleted from the map.
				inven.item3 = true; 
				inven.item3Active = false;
				Destroy (gameObject);
			}
			if (gameObject.name == "IntroBox") { // the player has moved into the introBox.
				inven.moveTrigger = true;
			}
		}
	}
}
