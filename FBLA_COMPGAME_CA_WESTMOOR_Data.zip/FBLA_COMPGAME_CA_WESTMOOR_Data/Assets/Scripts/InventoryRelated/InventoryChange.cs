﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryChange : MonoBehaviour {
	public GameObject[] inventory, GGitems;
	public bool item1, item2, item3;
	private VariableScript inven;

	public Text moneyText; 
	// Use this for initialization
	void Start () {
		inven = FindObjectOfType<VariableScript> (); // To access the VariableScript script.
		inventory [0].SetActive (false); // The item is disabled.
		inventory [1].SetActive (false); // The item is disabled.
		inventory [2].SetActive (false); // The item is disabled.
		GGitems [0].SetActive (false); // The item is disabled.
		GGitems [1].SetActive (false); // The item is disabled.
		moneyText.text = ("");  // The text is empty.
	}
	
	// Update is called once per frame
	void Update () { // If the player has/used the item...
		if (inven.item1) {
			inventory [0].SetActive (true); // The bottle is activated.
			moneyText.text = ("$" + inven.money + "/$100"); // The bottle shows how much money you have.
		}
		if (inven.item2) {
			inventory [1].SetActive (true); // The object is activated.
		}
		if (inven.item3) {
			inventory [2].SetActive (true); // The object is activated.
		}

		if (inven.banana) {
			GGitems[0].SetActive (true); // The object is activated.
		}
		if (inven.composted) {
			GGitems[0].SetActive(false); // The object is activated.
		}
		if (inven.plant) {
			GGitems [1].SetActive (true); // The object is activated.
		}
		if (inven.planted) {
			GGitems[1].SetActive(false); // The object is activated.
		}

	}
}
